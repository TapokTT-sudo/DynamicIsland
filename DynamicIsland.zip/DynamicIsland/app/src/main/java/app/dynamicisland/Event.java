package app.dynamicisland;

import android.app.PendingIntent;
import android.graphics.drawable.Drawable;

/** Одно «событие» для острова: уведомление, трек, зарядка или тест. */
final class Event {
    static final int NOTIF = 0;
    static final int MEDIA = 1;
    static final int CHARGING = 2;
    static final int TEST = 3;

    int type;
    CharSequence title;
    CharSequence text;
    Drawable icon;
    /** true — иконку вписать целиком (системные глифы), false — обрезать по квадрату (аватарки, обложки). */
    boolean fit;
    /** Что открыть по нажатию на развёрнутый остров. */
    PendingIntent action;
    boolean playing;
}
