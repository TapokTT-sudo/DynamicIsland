package app.dynamicisland;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.ActivityOptions;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/**
 * Управляет окном-оверлеем «острова»: создаёт его, анимирует размеры между
 * состояниями (скрыт / в покое / компактный / развёрнутый) и обрабатывает нажатия.
 * Все публичные методы можно вызывать из любого потока.
 */
final class IslandController {
    static final int HIDDEN = -1;
    static final int IDLE = 0;
    static final int COMPACT = 1;
    static final int EXPANDED = 2;

    private static IslandController instance;

    static synchronized IslandController get(Context c) {
        if (instance == null) {
            instance = new IslandController(c.getApplicationContext());
        }
        return instance;
    }

    private final Context app;
    private final WindowManager wm;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable restTask = new Runnable() {
        @Override
        public void run() {
            rest();
        }
    };

    private IslandView view;
    private WindowManager.LayoutParams lp;
    private GestureDetector gestures;
    private boolean attached;
    private boolean active;
    private int state = HIDDEN;
    private Event current;
    private Event media;
    private ValueAnimator anim;
    private float curW;
    private float curH;
    private float curR;

    private IslandController(Context appContext) {
        app = appContext;
        wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
    }

    // ---------------------------------------------------------------- публичное API

    /** Сервис запущен: показываем остров в покое. */
    void start() {
        run(() -> {
            active = true;
            rest();
        });
    }

    /** Сервис остановлен: убираем остров с экрана. */
    void stop() {
        run(() -> {
            active = false;
            handler.removeCallbacks(restTask);
            cancelAnim();
            detach();
            state = HIDDEN;
            current = null;
            media = null;
        });
    }

    /** Показать событие (уведомление, зарядка, тест). */
    void post(final Event e) {
        run(() -> {
            if (!canDraw()) {
                return;
            }
            if (e.type != Event.TEST && !Prefs.getBool(app, Prefs.ENABLED)) {
                return;
            }
            if (!typeAllowed(e.type)) {
                return;
            }
            current = e;
            expand();
        });
    }

    /** Обновить информацию о текущем треке (null — музыки нет). */
    void setMedia(final Event e) {
        run(() -> {
            Event old = media;
            media = e;
            if (!canDraw() || !Prefs.getBool(app, Prefs.ENABLED) || !Prefs.getBool(app, Prefs.MEDIA)) {
                return;
            }
            if (e == null || !e.playing) {
                if (state == COMPACT) {
                    rest();
                }
                return;
            }
            boolean changed = old == null || !old.playing || !TextUtils.equals(old.title, e.title);
            if (changed) {
                current = e;
                expand();
            } else if (view != null && (state == COMPACT
                    || (state == EXPANDED && current != null && current.type == Event.MEDIA))) {
                current = e;
                view.bind(e);
            }
        });
    }

    /** Применить изменённые настройки (размеры, цвет, позиция) без анимации. */
    void applySettings() {
        run(() -> {
            if (!attached || view == null) {
                return;
            }
            if (state == HIDDEN) {
                cancelAnim();
                detach();
                return;
            }
            lp.y = dp(Prefs.getInt(app, Prefs.TOP));
            applyColor();
            setMode(state);
            cancelAnim();
            curW = targetW(state);
            curH = targetH(state);
            curR = targetR(state);
            applyFrame();
        });
    }

    /** Пересчитать состояние покоя (например, после переключения «показывать в покое»). */
    void refresh() {
        run(() -> {
            if (state == EXPANDED) {
                applySettings();
            } else {
                rest();
            }
        });
    }

    /** Показать пример, чтобы оценить настройки. */
    void preview() {
        Event e = new Event();
        e.type = Event.TEST;
        e.title = "Предпросмотр";
        e.text = "Так выглядит ваш остров";
        e.icon = app.getDrawable(R.mipmap.ic_launcher);
        post(e);
    }

    // ---------------------------------------------------------------- состояния

    private void expand() {
        if (current == null || !canDraw()) {
            return;
        }
        boolean wasExpanded = state == EXPANDED;
        ensureAttached();
        if (view == null) {
            return;
        }
        applyColor();
        view.bind(current);
        setMode(EXPANDED);
        if (!wasExpanded) {
            buzz();
        }
        animateTo(EXPANDED);
        handler.removeCallbacks(restTask);
        handler.postDelayed(restTask, Prefs.getInt(app, Prefs.HOLD) * 1000L);
    }

    private void rest() {
        handler.removeCallbacks(restTask);
        if (!canDraw()) {
            cancelAnim();
            detach();
            state = HIDDEN;
            return;
        }
        boolean showMedia = active && media != null && media.playing && Prefs.getBool(app, Prefs.MEDIA);
        if (showMedia) {
            current = media;
            ensureAttached();
            if (view == null) {
                return;
            }
            applyColor();
            view.bind(media);
            setMode(COMPACT);
            animateTo(COMPACT);
        } else if (active && Prefs.getBool(app, Prefs.SHOW_IDLE)) {
            ensureAttached();
            if (view == null) {
                return;
            }
            applyColor();
            setMode(IDLE);
            animateTo(IDLE);
        } else if (attached && view != null) {
            setMode(IDLE);
            animateTo(HIDDEN);
        } else {
            state = HIDDEN;
        }
    }

    private void setMode(int s) {
        int mode = s == COMPACT ? IslandView.M_COMPACT
                : s == EXPANDED ? IslandView.M_EXPANDED : IslandView.M_IDLE;
        view.setMode(mode,
                dp(Prefs.getInt(app, Prefs.IDLE_H)),
                dp(Prefs.getInt(app, Prefs.EXP_H)),
                Math.round(targetW(EXPANDED)));
    }

    // ---------------------------------------------------------------- нажатия

    private void onTap() {
        if (state == EXPANDED) {
            Event e = current;
            if (e != null && e.action != null) {
                fire(e.action);
            }
            rest();
        } else if (state == COMPACT && media != null) {
            current = media;
            expand();
        }
    }

    private void openApp() {
        Intent i = new Intent(app, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            app.startActivity(i);
        } catch (Exception ignored) {
            // нет права запускать активность из фона — просто игнорируем
        }
    }

    private void fire(PendingIntent pi) {
        try {
            Bundle opts = null;
            if (Build.VERSION.SDK_INT >= 34) {
                ActivityOptions ao = ActivityOptions.makeBasic();
                ao.setPendingIntentBackgroundActivityStartMode(
                        ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED);
                opts = ao.toBundle();
            }
            pi.send(app, 0, null, null, null, null, opts);
        } catch (Exception ignored) {
            // интент мог устареть — не страшно
        }
    }

    private void buzz() {
        if (!Prefs.getBool(app, Prefs.HAPTIC)) {
            return;
        }
        Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null && v.hasVibrator()) {
            v.vibrate(VibrationEffect.createOneShot(12, 60));
        }
    }

    // ---------------------------------------------------------------- окно и анимация

    private void ensureAttached() {
        if (attached) {
            return;
        }
        view = new IslandView(app);
        gestures = new GestureDetector(app, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                onTap();
                return true;
            }

            @Override
            public void onLongPress(MotionEvent e) {
                openApp();
            }
        });
        view.setOnTouchListener((v, ev) -> gestures.onTouchEvent(ev));

        curW = dp(Prefs.getInt(app, Prefs.IDLE_W)) * 0.3f;
        curH = dp(Prefs.getInt(app, Prefs.IDLE_H)) * 0.3f;
        curR = curH / 2f;

        lp = new WindowManager.LayoutParams(
                Math.max(1, Math.round(curW)),
                Math.max(1, Math.round(curH)),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(Prefs.getInt(app, Prefs.TOP));
        lp.setTitle("DynamicIsland");
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        view.setRadius(curR);
        try {
            wm.addView(view, lp);
            attached = true;
        } catch (Exception ex) {
            // нет разрешения «поверх других окон» или система отказала
            view = null;
            attached = false;
        }
    }

    private void detach() {
        if (attached && view != null) {
            try {
                wm.removeView(view);
            } catch (Exception ignored) {
                // окно уже убрано
            }
        }
        attached = false;
        view = null;
    }

    private void animateTo(final int target) {
        cancelAnim();
        state = target;
        if (view == null) {
            return;
        }
        final float fromW = curW;
        final float fromH = curH;
        final float fromR = curR;
        final float toW = targetW(target);
        final float toH = targetH(target);
        final float toR = targetR(target);
        int dur = Prefs.getInt(app, Prefs.ANIM);

        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(target == EXPANDED ? dur : (long) (dur * 0.8f));
        if (target == EXPANDED && Prefs.getBool(app, Prefs.BOUNCE)) {
            a.setInterpolator(new OvershootInterpolator(1.4f));
        } else {
            a.setInterpolator(new DecelerateInterpolator(1.6f));
        }
        a.addUpdateListener(va -> {
            float f = (float) va.getAnimatedValue();
            curW = fromW + (toW - fromW) * f;
            curH = fromH + (toH - fromH) * f;
            curR = fromR + (toR - fromR) * f;
            applyFrame();
        });
        a.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!cancelled && target == HIDDEN) {
                    detach();
                }
            }
        });
        anim = a;
        a.start();
    }

    private void cancelAnim() {
        if (anim != null) {
            ValueAnimator a = anim;
            anim = null;
            a.cancel();
        }
    }

    private void applyFrame() {
        if (!attached || view == null) {
            return;
        }
        float w = Math.max(1f, Math.min(curW, screenW()));
        float h = Math.max(1f, curH);
        lp.width = Math.round(w);
        lp.height = Math.round(h);
        view.setRadius(Math.min(curR, Math.min(w, h) / 2f));
        try {
            wm.updateViewLayout(view, lp);
        } catch (Exception ignored) {
            // окно могло быть убрано
        }
    }

    private void applyColor() {
        if (view != null) {
            view.setIslandColor(Prefs.getInt(app, Prefs.COLOR));
        }
    }

    // ---------------------------------------------------------------- размеры

    private float targetW(int s) {
        float idle = dp(Prefs.getInt(app, Prefs.IDLE_W));
        float max = screenW() - dp(16);
        switch (s) {
            case EXPANDED:
                return Math.min(dp(Prefs.getInt(app, Prefs.EXP_W)), max);
            case COMPACT:
                return Math.min(idle + dp(76), max);
            case IDLE:
                return idle;
            default:
                return idle * 0.3f;
        }
    }

    private float targetH(int s) {
        float idle = dp(Prefs.getInt(app, Prefs.IDLE_H));
        switch (s) {
            case EXPANDED:
                return dp(Prefs.getInt(app, Prefs.EXP_H));
            case COMPACT:
            case IDLE:
                return idle;
            default:
                return idle * 0.3f;
        }
    }

    private float targetR(int s) {
        float h = targetH(s);
        if (s == EXPANDED) {
            return Math.min(dp(Prefs.getInt(app, Prefs.RADIUS)), h / 2f);
        }
        return h / 2f;
    }

    private int screenW() {
        return app.getResources().getDisplayMetrics().widthPixels;
    }

    private int dp(float v) {
        return Math.round(v * app.getResources().getDisplayMetrics().density);
    }

    // ---------------------------------------------------------------- прочее

    private boolean canDraw() {
        return Settings.canDrawOverlays(app);
    }

    private boolean typeAllowed(int type) {
        switch (type) {
            case Event.NOTIF:
                return Prefs.getBool(app, Prefs.NOTIFS);
            case Event.MEDIA:
                return Prefs.getBool(app, Prefs.MEDIA);
            case Event.CHARGING:
                return Prefs.getBool(app, Prefs.CHARGING);
            default:
                return true;
        }
    }

    private void run(Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
        } else {
            handler.post(r);
        }
    }
}
