package app.dynamicisland;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Три прыгающие полоски, как у музыки в Dynamic Island. */
final class EqualizerView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private ValueAnimator animator;
    private float phase;
    private boolean playing;

    EqualizerView(Context c) {
        super(c);
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL);
    }

    void setPlaying(boolean on) {
        playing = on;
        if (on && isAttachedToWindow()) {
            start();
        } else {
            stop();
        }
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (playing) {
            start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    private void start() {
        if (animator != null) {
            return;
        }
        animator = ValueAnimator.ofFloat(0f, (float) (2 * Math.PI));
        animator.setDuration(900);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    private void stop() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        float bw = w / 5f;
        for (int i = 0; i < 3; i++) {
            float f = 0.3f;
            if (playing) {
                f = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(phase * (1 + i * 0.6f) + i * 1.7f));
            }
            float bh = h * f;
            float x = i * 2 * bw;
            canvas.drawRoundRect(x, (h - bh) / 2f, x + bw, (h + bh) / 2f, bw / 2f, bw / 2f, paint);
        }
    }
}
