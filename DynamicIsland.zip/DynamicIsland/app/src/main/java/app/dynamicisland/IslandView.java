package app.dynamicisland;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Outline;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Сам «остров»: чёрная скруглённая капсула с иконкой, текстом и эквалайзером. */
final class IslandView extends FrameLayout {
    static final int M_IDLE = 0;
    static final int M_COMPACT = 1;
    static final int M_EXPANDED = 2;

    private final ImageView icon;
    private final LinearLayout box;
    private final TextView title;
    private final TextView text;
    private final EqualizerView eq;

    private float radius;
    private boolean eqWanted;
    private int mode = -1;

    IslandView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        setClipToOutline(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radius);
            }
        });

        icon = new ImageView(c);
        icon.setClipToOutline(true);
        icon.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), v.getWidth() * 0.25f);
            }
        });

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);

        title = new TextView(c);
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);

        text = new TextView(c);
        text.setTextColor(0xB3FFFFFF);
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        text.setMaxLines(2);
        text.setEllipsize(TextUtils.TruncateAt.END);

        box.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(text, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        eq = new EqualizerView(c);

        addView(icon, new FrameLayout.LayoutParams(dp(24), dp(24)));
        addView(box, new FrameLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT));
        addView(eq, new FrameLayout.LayoutParams(dp(18), dp(14)));

        icon.setVisibility(GONE);
        box.setVisibility(GONE);
        eq.setVisibility(GONE);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    void setIslandColor(int color) {
        setBackgroundColor(color);
    }

    void setRadius(float r) {
        radius = r;
        invalidateOutline();
    }

    void bind(Event e) {
        title.setText(e.title);
        if (TextUtils.isEmpty(e.text)) {
            text.setVisibility(GONE);
        } else {
            text.setVisibility(VISIBLE);
            text.setText(e.text);
        }
        icon.setImageDrawable(e.icon);
        icon.setScaleType(e.fit ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
        eqWanted = e.type == Event.MEDIA && e.playing;
        eq.setPlaying(eqWanted);
    }

    void setMode(int newMode, int idleH, int expH, int expW) {
        icon.animate().cancel();
        box.animate().cancel();
        eq.animate().cancel();
        boolean same = newMode == mode;
        mode = newMode;

        if (newMode == M_IDLE) {
            icon.setVisibility(GONE);
            box.setVisibility(GONE);
            eq.setVisibility(GONE);
            return;
        }

        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(0, 0);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(dp(18), dp(14));

        if (newMode == M_COMPACT) {
            int s = Math.max(dp(16), idleH - dp(12));
            ip.width = s;
            ip.height = s;
            ip.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
            ip.leftMargin = dp(10);
            icon.setLayoutParams(ip);

            ep.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
            ep.rightMargin = dp(12);
            eq.setLayoutParams(ep);

            box.setVisibility(GONE);
            show(icon, same, 0);
            show(eq, same, 0);
        } else {
            int s = Math.max(dp(24), Math.min(dp(48), expH - dp(24)));
            int left = dp(18);
            int gap = dp(12);
            int right = dp(18) + (eqWanted ? dp(18) + dp(10) : 0);

            ip.width = s;
            ip.height = s;
            ip.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
            ip.leftMargin = left;
            icon.setLayoutParams(ip);

            bp.width = Math.max(dp(40), expW - left - s - gap - right);
            bp.leftMargin = left + s + gap;
            bp.gravity = Gravity.START | Gravity.CENTER_VERTICAL;
            box.setLayoutParams(bp);

            ep.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
            ep.rightMargin = dp(18);
            eq.setLayoutParams(ep);

            show(icon, same, 0);
            show(box, same, 110);
            if (eqWanted) {
                show(eq, same, 110);
            } else {
                eq.setVisibility(GONE);
            }
        }
    }

    private void show(View v, boolean keep, long delay) {
        v.setVisibility(VISIBLE);
        if (keep) {
            v.setAlpha(1f);
            return;
        }
        v.setAlpha(0f);
        v.animate().alpha(1f).setStartDelay(delay).setDuration(200).start();
    }
}
