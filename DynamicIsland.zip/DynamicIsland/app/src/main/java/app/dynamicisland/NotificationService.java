package app.dynamicisland;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

import java.util.List;

/**
 * Слушает уведомления и активные медиасессии (музыку) и передаёт их острову.
 * Для работы пользователь должен выдать «Доступ к уведомлениям».
 */
public class NotificationService extends NotificationListenerService {
    private MediaSessionManager sessions;
    private MediaController tracked;
    private String lastSig = "";
    private long lastTime;

    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            pushMedia();
        }

        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            pushMedia();
        }
    };

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionListener =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override
                public void onActiveSessionsChanged(List<MediaController> controllers) {
                    pick(controllers);
                }
            };

    // ---------------------------------------------------------------- уведомления

    @Override
    public void onNotificationPosted(StatusBarNotification sbn, RankingMap rankingMap) {
        if (sbn == null) {
            return;
        }
        if (!Prefs.getBool(this, Prefs.ENABLED) || !Prefs.getBool(this, Prefs.NOTIFS)) {
            return;
        }
        String pkg = sbn.getPackageName();
        if (getPackageName().equals(pkg)) {
            return;
        }
        Notification n = sbn.getNotification();
        if (n == null) {
            return;
        }
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
            return;
        }
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 && !Prefs.getBool(this, Prefs.ONGOING)) {
            return;
        }
        if (Notification.CATEGORY_TRANSPORT.equals(n.category)) {
            return;
        }
        if (Prefs.getBool(this, Prefs.ONLY_ALERTING) && rankingMap != null) {
            Ranking r = new Ranking();
            if (rankingMap.getRanking(sbn.getKey(), r)
                    && r.getImportance() < NotificationManager.IMPORTANCE_DEFAULT) {
                return;
            }
        }

        Bundle x = n.extras;
        if (x == null) {
            return;
        }
        CharSequence title = x.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence text = x.getCharSequence(Notification.EXTRA_TEXT);
        if (TextUtils.isEmpty(text)) {
            text = x.getCharSequence(Notification.EXTRA_BIG_TEXT);
        }
        if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text)) {
            return;
        }
        String label = appLabel(pkg);
        if (TextUtils.isEmpty(title)) {
            title = label;
        }
        if (TextUtils.isEmpty(text)) {
            text = label;
        }

        // Приложения часто обновляют одно и то же уведомление — не дёргаем остров повторно.
        String sig = sbn.getKey() + "|" + title + "|" + text;
        long now = System.currentTimeMillis();
        if (sig.equals(lastSig) && now - lastTime < 3000) {
            return;
        }
        lastSig = sig;
        lastTime = now;

        Drawable icon = null;
        try {
            Icon large = n.getLargeIcon();
            if (large != null) {
                icon = large.loadDrawable(this);
            }
        } catch (Exception ignored) {
            // не смогли загрузить — возьмём иконку приложения
        }
        if (icon == null) {
            icon = appIcon(pkg);
        }

        Event e = new Event();
        e.type = Event.NOTIF;
        e.title = title;
        e.text = text;
        e.icon = icon;
        e.action = n.contentIntent;
        IslandController.get(this).post(e);
    }

    // ---------------------------------------------------------------- музыка

    @Override
    public void onListenerConnected() {
        try {
            ComponentName me = new ComponentName(this, NotificationService.class);
            sessions = (MediaSessionManager) getSystemService(Context.MEDIA_SESSION_SERVICE);
            sessions.addOnActiveSessionsChangedListener(sessionListener, me);
            pick(sessions.getActiveSessions(me));
        } catch (SecurityException ignored) {
            // нет доступа к сессиям
        }
    }

    @Override
    public void onListenerDisconnected() {
        if (sessions != null) {
            try {
                sessions.removeOnActiveSessionsChangedListener(sessionListener);
            } catch (Exception ignored) {
                // уже снят
            }
        }
        untrack();
        IslandController.get(this).setMedia(null);
    }

    private void pick(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    best = c;
                    break;
                }
            }
            if (best == null && !list.isEmpty()) {
                best = list.get(0);
            }
        }
        untrack();
        tracked = best;
        if (best != null) {
            best.registerCallback(callback);
        }
        pushMedia();
    }

    private void untrack() {
        if (tracked != null) {
            try {
                tracked.unregisterCallback(callback);
            } catch (Exception ignored) {
                // уже снят
            }
            tracked = null;
        }
    }

    private void pushMedia() {
        MediaController c = tracked;
        if (c == null) {
            IslandController.get(this).setMedia(null);
            return;
        }
        PlaybackState s = c.getPlaybackState();
        MediaMetadata m = c.getMetadata();
        String pkg = c.getPackageName();

        Event e = new Event();
        e.type = Event.MEDIA;
        e.playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;

        CharSequence title = m != null ? m.getString(MediaMetadata.METADATA_KEY_TITLE) : null;
        CharSequence artist = m != null ? m.getString(MediaMetadata.METADATA_KEY_ARTIST) : null;
        if (TextUtils.isEmpty(artist) && m != null) {
            artist = m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
        }
        e.title = TextUtils.isEmpty(title) ? appLabel(pkg) : title;
        e.text = artist;

        Bitmap art = null;
        if (m != null) {
            art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) {
                art = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
            }
        }
        e.icon = art != null ? new BitmapDrawable(getResources(), art) : appIcon(pkg);

        PendingIntent pi = c.getSessionActivity();
        if (pi == null) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                pi = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE);
            }
        }
        e.action = pi;
        IslandController.get(this).setMedia(e);
    }

    // ---------------------------------------------------------------- помощники

    private String appLabel(String pkg) {
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(
                    getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }

    private Drawable appIcon(String pkg) {
        try {
            return getPackageManager().getApplicationIcon(pkg);
        } catch (Exception e) {
            return getDrawable(R.mipmap.ic_launcher);
        }
    }
}
