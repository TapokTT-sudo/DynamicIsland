package app.dynamicisland;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Экран настроек острова. Весь интерфейс собирается кодом, без XML-раскладок. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF000000;
    private static final int CARD = 0xFF1C1C1E;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF8E8E93;
    private static final int GREEN = 0xFF30D158;
    private static final int RED = 0xFFFF453A;
    private static final int ACCENT = 0xFFFF9F0A;

    private static final int[] PALETTE = {
            0xFF000000, 0xFF1C1C1E, 0xFF0A1A33, 0xFF2B1055, 0xFF0B2E1E, 0xFF3A0D18
    };

    private LinearLayout root;
    private LinearLayout colorRow;
    private TextView overlayStatus;
    private TextView listenerStatus;
    private TextView notifStatus;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(40));
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);

        build();

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        // Если остров включён, но сервис не работает (например, процесс убили) — поднимаем снова.
        if (Prefs.getBool(this, Prefs.ENABLED) && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(new Intent(this, IslandService.class));
            } catch (Exception ignored) {
                // система не дала запустить — пользователь включит вручную
            }
        }
    }

    // ---------------------------------------------------------------- интерфейс

    private void build() {
        TextView title = text("Остров", 32, WHITE);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);
        root.addView(text("Dynamic Island для Android", 15, GRAY));

        // --- включение
        section("Включение");
        LinearLayout c0 = card();
        final Switch master = new Switch(this);
        master.setText("Остров включён");
        master.setTextColor(WHITE);
        master.setTextSize(17);
        master.setPadding(0, dp(10), 0, dp(10));
        master.setChecked(Prefs.getBool(this, Prefs.ENABLED) && Settings.canDrawOverlays(this));
        master.setOnCheckedChangeListener((v, on) -> {
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    v.setChecked(false);
                    Toast.makeText(this, "Сначала разрешите «Поверх других окон»", Toast.LENGTH_LONG).show();
                    openOverlaySettings();
                    return;
                }
                Prefs.setBool(this, Prefs.ENABLED, true);
                startForegroundService(new Intent(this, IslandService.class));
            } else {
                Prefs.setBool(this, Prefs.ENABLED, false);
                stopService(new Intent(this, IslandService.class));
            }
        });
        c0.addView(master, matchWrap());

        // --- разрешения
        section("Разрешения");
        LinearLayout c1 = card();
        overlayStatus = permRow(c1, "Поверх других окон",
                "Нужно, чтобы рисовать остров над приложениями", this::openOverlaySettings);
        listenerStatus = permRow(c1, "Доступ к уведомлениям",
                "Чтобы показывать уведомления и музыку",
                () -> safeStart(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        notifStatus = permRow(c1, "Уведомление сервиса",
                "Иначе система может «убить» остров в фоне", () -> {
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                    } else {
                        safeStart(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                    }
                });

        // --- что показывать
        section("Что показывать");
        LinearLayout c2 = card();
        switchRow(c2, "Уведомления", Prefs.NOTIFS);
        switchRow(c2, "Музыка (пока играет)", Prefs.MEDIA);
        switchRow(c2, "Зарядка", Prefs.CHARGING);
        switchRow(c2, "Только важные уведомления", Prefs.ONLY_ALERTING);
        switchRow(c2, "Постоянные (навигация, таймеры)", Prefs.ONGOING);

        // --- внешний вид
        section("Внешний вид");
        LinearLayout c3 = card();
        switchRow(c3, "Показывать остров в покое", Prefs.SHOW_IDLE);
        colorRow(c3);
        slider(c3, "Ширина в покое", Prefs.IDLE_W, 60, 220, "dp");
        slider(c3, "Высота в покое", Prefs.IDLE_H, 20, 60, "dp");
        slider(c3, "Отступ от верха", Prefs.TOP, 0, 80, "dp");
        slider(c3, "Ширина развёрнутого", Prefs.EXP_W, 200, 420, "dp");
        slider(c3, "Высота развёрнутого", Prefs.EXP_H, 60, 140, "dp");
        slider(c3, "Скругление", Prefs.RADIUS, 12, 60, "dp");

        // --- анимация
        section("Анимация и отклик");
        LinearLayout c4 = card();
        slider(c4, "Скорость анимации", Prefs.ANIM, 150, 700, "мс");
        slider(c4, "Сколько держать развёрнутым", Prefs.HOLD, 2, 12, "сек");
        switchRow(c4, "Пружинистая анимация", Prefs.BOUNCE);
        switchRow(c4, "Вибрация при появлении", Prefs.HAPTIC);

        // --- кнопки
        LinearLayout c5 = card();
        Button preview = button("Показать пример");
        preview.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала разрешите «Поверх других окон»", Toast.LENGTH_LONG).show();
                return;
            }
            IslandController.get(this).preview();
        });
        c5.addView(preview, matchWrap());
        Button reset = button("Сбросить настройки");
        reset.setOnClickListener(v -> {
            stopService(new Intent(this, IslandService.class));
            Prefs.sp(this).edit().clear().apply();
            IslandController.get(this).applySettings();
            recreate();
        });
        c5.addView(reset, matchWrap());

        // --- подсказки
        section("Если что-то не работает");
        LinearLayout c6 = card();
        TextView help = text(
                "• Остров пропадает через время (Vivo / OriginOS): включите «Автозапуск» и "
                        + "«Фоновое энергопотребление → Разрешить» для этого приложения, закрепите его в многозадачности.\n\n"
                        + "• Пункт «Доступ к уведомлениям» серый (Android 13+): «О приложении» → ⋮ → "
                        + "«Разрешить ограниченные настройки», потом снова откройте доступ.\n\n"
                        + "• Остров мимо камеры: подгоните «Отступ от верха», ширину и высоту ползунками.\n\n"
                        + "• Нажатие на остров открывает уведомление, долгое нажатие — эти настройки.",
                14, GRAY);
        help.setPadding(0, dp(8), 0, dp(8));
        c6.addView(help, matchWrap());
        Button info = button("О приложении");
        info.setOnClickListener(v -> safeStart(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        c6.addView(info, matchWrap());
        Button battery = button("Настройки батареи");
        battery.setOnClickListener(v ->
                safeStart(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        c6.addView(battery, matchWrap());
    }

    private void section(String title) {
        TextView t = text(title.toUpperCase(), 13, GRAY);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(22);
        root.addView(t, lp);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(16));
        c.setBackground(bg);
        c.setPadding(dp(16), dp(8), dp(16), dp(8));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(8);
        root.addView(c, lp);
        return c;
    }

    private TextView permRow(LinearLayout parent, String title, String hint, final Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(8), 0, dp(8));
        row.addView(text(title, 16, WHITE));
        row.addView(text(hint, 13, GRAY));
        TextView status = text("", 14, GRAY);
        row.addView(status);
        Button open = button("Открыть");
        open.setOnClickListener(v -> action.run());
        row.addView(open, matchWrap());
        parent.addView(row, matchWrap());
        return status;
    }

    private void switchRow(LinearLayout parent, String label, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(WHITE);
        s.setTextSize(16);
        s.setPadding(0, dp(10), 0, dp(10));
        s.setChecked(Prefs.getBool(this, key));
        s.setOnCheckedChangeListener((v, on) -> {
            Prefs.setBool(this, key, on);
            if (key.equals(Prefs.SHOW_IDLE) || key.equals(Prefs.MEDIA)) {
                IslandController.get(this).refresh();
            }
        });
        parent.addView(s, matchWrap());
    }

    private void slider(LinearLayout parent, final String label, final String key,
                        final int min, final int max, final String unit) {
        int cur = Prefs.getInt(this, key);
        final TextView t = text(label + ": " + cur + " " + unit, 15, WHITE);
        t.setPadding(0, dp(8), 0, 0);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(Math.max(0, Math.min(max - min, cur - min)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = progress + min;
                t.setText(label + ": " + v + " " + unit);
                if (fromUser) {
                    Prefs.setInt(MainActivity.this, key, v);
                    IslandController.get(MainActivity.this).applySettings();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                IslandController.get(MainActivity.this).preview();
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                IslandController.get(MainActivity.this).preview();
            }
        });
        parent.addView(t, matchWrap());
        parent.addView(sb, matchWrap());
    }

    private void colorRow(LinearLayout parent) {
        TextView t = text("Цвет острова", 15, WHITE);
        t.setPadding(0, dp(8), 0, dp(6));
        parent.addView(t, matchWrap());
        colorRow = new LinearLayout(this);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorRow.setPadding(0, dp(4), 0, dp(10));
        for (final int color : PALETTE) {
            View dot = new View(this);
            dot.setOnClickListener(v -> {
                Prefs.setInt(this, Prefs.COLOR, color);
                refreshColors();
                IslandController.get(this).applySettings();
                IslandController.get(this).preview();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
            lp.rightMargin = dp(12);
            colorRow.addView(dot, lp);
        }
        parent.addView(colorRow, matchWrap());
        refreshColors();
    }

    private void refreshColors() {
        int cur = Prefs.getInt(this, Prefs.COLOR);
        for (int i = 0; i < colorRow.getChildCount(); i++) {
            boolean selected = cur == PALETTE[i];
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(PALETTE[i]);
            d.setStroke(dp(selected ? 3 : 1), selected ? ACCENT : 0xFF48484A);
            colorRow.getChildAt(i).setBackground(d);
        }
    }

    // ---------------------------------------------------------------- состояние и переходы

    private void updateStatus() {
        setStatus(overlayStatus, Settings.canDrawOverlays(this));
        setStatus(listenerStatus, listenerEnabled());
        boolean notif = Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        setStatus(notifStatus, notif);
    }

    private void setStatus(TextView t, boolean ok) {
        if (t == null) {
            return;
        }
        t.setText(ok ? "✓ Разрешено" : "✗ Не разрешено");
        t.setTextColor(ok ? GREEN : RED);
    }

    private boolean listenerEnabled() {
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        String me = new ComponentName(this, NotificationService.class).flattenToString();
        return flat != null && flat.contains(me);
    }

    private void openOverlaySettings() {
        safeStart(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())));
    }

    private void safeStart(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть настройки. Откройте их вручную.", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------------------------------------------------------- мелочи

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
