package app.dynamicisland;

import android.content.Context;
import android.content.SharedPreferences;

/** Все настройки острова в одном месте. Значения по умолчанию заданы здесь же. */
final class Prefs {
    static final String ENABLED = "enabled";
    static final String SHOW_IDLE = "show_idle";
    static final String NOTIFS = "notifs";
    static final String MEDIA = "media";
    static final String CHARGING = "charging";
    static final String ONLY_ALERTING = "only_alerting";
    static final String ONGOING = "ongoing";
    static final String HAPTIC = "haptic";
    static final String BOUNCE = "bounce";

    static final String IDLE_W = "idle_w";   // dp
    static final String IDLE_H = "idle_h";   // dp
    static final String TOP = "top";         // dp, отступ от верха экрана
    static final String EXP_W = "exp_w";     // dp
    static final String EXP_H = "exp_h";     // dp
    static final String RADIUS = "radius";   // dp
    static final String HOLD = "hold";       // секунды
    static final String ANIM = "anim";       // миллисекунды
    static final String COLOR = "color";     // ARGB

    private Prefs() {}

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("island_prefs", Context.MODE_PRIVATE);
    }

    static int defInt(String k) {
        switch (k) {
            case IDLE_W: return 112;
            case IDLE_H: return 32;
            case TOP: return 8;
            case EXP_W: return 340;
            case EXP_H: return 84;
            case RADIUS: return 34;
            case HOLD: return 5;
            case ANIM: return 380;
            case COLOR: return 0xFF000000;
            default: return 0;
        }
    }

    static boolean defBool(String k) {
        switch (k) {
            case ENABLED: return false;
            case ONGOING: return false;
            default: return true;
        }
    }

    static int getInt(Context c, String k) {
        return sp(c).getInt(k, defInt(k));
    }

    static void setInt(Context c, String k, int v) {
        sp(c).edit().putInt(k, v).apply();
    }

    static boolean getBool(Context c, String k) {
        return sp(c).getBoolean(k, defBool(k));
    }

    static void setBool(Context c, String k, boolean v) {
        sp(c).edit().putBoolean(k, v).apply();
    }
}
