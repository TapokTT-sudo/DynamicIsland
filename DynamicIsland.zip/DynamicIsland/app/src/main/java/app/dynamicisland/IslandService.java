package app.dynamicisland;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;

/** Держит процесс живым и показывает остров. Также ловит подключение зарядки. */
public class IslandService extends Service {
    private static final String CHANNEL = "island_service";
    private static final int NOTIF_ID = 1;

    private final BroadcastReceiver power = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            String action = intent.getAction();
            if (action == null) {
                return;
            }
            boolean on = Intent.ACTION_POWER_CONNECTED.equals(action);
            boolean off = Intent.ACTION_POWER_DISCONNECTED.equals(action);
            if (!on && !off) {
                return;
            }
            Event e = new Event();
            e.type = Event.CHARGING;
            e.title = on ? "Зарядка" : "Зарядка отключена";
            e.text = (on ? "Подключено · " : "Заряд · ") + batteryPercent() + "%";
            e.icon = ctx.getDrawable(android.R.drawable.ic_lock_idle_charging);
            e.fit = true;
            IslandController.get(ctx).post(e);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Остров", NotificationManager.IMPORTANCE_LOW));

        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_island)
                .setContentTitle("Остров работает")
                .setContentText("Нажмите, чтобы открыть настройки")
                .setContentIntent(open)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(power, f);
        }

        IslandController.get(this).start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try {
            unregisterReceiver(power);
        } catch (Exception ignored) {
            // уже отписан
        }
        IslandController.get(this).stop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int batteryPercent() {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) {
            return 0;
        }
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return scale > 0 && level >= 0 ? Math.round(level * 100f / scale) : 0;
    }
}
