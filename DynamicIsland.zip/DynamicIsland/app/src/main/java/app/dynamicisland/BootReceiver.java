package app.dynamicisland;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** Запускает остров после перезагрузки телефона, если он был включён. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            return;
        }
        if (Prefs.getBool(context, Prefs.ENABLED) && Settings.canDrawOverlays(context)) {
            try {
                context.startForegroundService(new Intent(context, IslandService.class));
            } catch (Exception ignored) {
                // система не разрешила старт из фона
            }
        }
    }
}
